export function initPageEvents() {

  const addMessageBtn = document.getElementById("addMessage");
  if (addMessageBtn) {
    addMessageBtn.addEventListener("click", () => {
      const params = new URLSearchParams(window.location.search);
      const topologyId = params.get("id");

      window.location.href = `add-message.html?topology_id=${topologyId}`;
    });
  }

  const addSignalBtn = document.getElementById("addSignal");
  if (addSignalBtn) {
    addSignalBtn.addEventListener("click", () => {
      const params1 = new URLSearchParams(window.location.search);
      const topologyId1 = params1.get("id");

      window.location.href = `addSig.html?topology_id=${topologyId1}`;
    });
  }

  const backBtn = document.getElementById("backToHomePage");
  if (backBtn) {
    backBtn.addEventListener("click", () => {
      window.location.href = "/";
    });
  }

  // const dbcBtn = document.getElementById("createDbcBtn");
  // if (dbcBtn) {
  //   dbcBtn.addEventListener("click", () => {
  //     alert("This Page is under construction.");
  //   });
  // }

  // const backToTopology = document.getElementsById("backToTopology");
  // if (backToTopology) {
  //   backToTopology.addEventListener("click", () => {
  //     const params = new URLSearchParams(window.location.search);
  //     const topologyId = params.get("topology_id");

  //     window.location.href = `topology.html?id=${topologyId}`;
  //   });
  // }

}
