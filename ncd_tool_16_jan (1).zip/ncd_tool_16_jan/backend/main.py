import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.metadata.metadata import router as metadata_router
from api.channels.channels import router as channels_router
from api.ecus.ecus import router as ecu_router
from api.messages.messages import router as messages_router
from api.signals.signals import router as signals_router
from api.can_dbc.can_dbc import router as dbc_router
from db.database import engine, Base
import os
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(BASE_DIR, "../frontend")

# Serve static files (CSS, JS)
app.mount(
    "/assets",
    StaticFiles(directory=os.path.join(FRONTEND_DIR, "assets")),
    name="assets"
)

# Homepage
@app.get("/")
def homepage():
    return FileResponse(os.path.join(FRONTEND_DIR, "metadata.html"))

@app.get("/topology.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "topology.html"))

@app.get("/add-message.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "add-message.html"))

@app.get("/addSig.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "addSig.html"))

@app.get("/message-list.html")
def message_list_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "message-list.html"))

@app.get("/signal-list.html")
def message_list_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "signal-list.html"))


@app.get("/navbar.html")
def navbar_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "navbar.html"))

@app.get("/metadata.html")
def metadata_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "metadata.html"))

app.include_router(metadata_router)
app.include_router(channels_router)
app.include_router(ecu_router)
app.include_router(messages_router)
app.include_router(signals_router)
app.include_router(dbc_router)

if __name__ == "__main__":
    uvicorn.run("main:app", reload=True, )
