from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base
import pytz

from sqlalchemy import Table

IST = pytz.timezone("Asia/Kolkata")

def ist_now():
    return datetime.now(IST)


class Metadata(Base):
    __tablename__ = "metadata_t"

    id = Column(Integer, primary_key=True, index=True)
    fileName = Column(String(50), nullable=False)
    version = Column(String(10))
    author = Column(String(20))
    created_at = Column(DateTime, default=ist_now)

    # 🔹 renamed from "channels.metadata"
    channels = relationship(
        "Channel",
        back_populates="parent_metadata",
        cascade="all, delete"
    )

channel_ecu = Table(
    "channel_ecu_t",
    Base.metadata,
    Column("channel_id", ForeignKey("channel_t.channel_id"), primary_key=True),
    Column("ecu_id", ForeignKey("ecu_t.ecu_id"), primary_key=True),
)

class Channel(Base):
    __tablename__ = "channel_t"

    channel_id = Column(Integer, primary_key=True, index=True)
    channel_name = Column(String(50), nullable=False)

    metadata_id = Column(
        Integer,
        ForeignKey("metadata_t.id", ondelete="CASCADE"),
        nullable=False
    )
    ecus = relationship("ECU", secondary=channel_ecu, back_populates="channels")
    # 🔹 DO NOT call this "metadata"
    parent_metadata = relationship(
        "Metadata",
        back_populates="channels"
    )


class ECU(Base):
    __tablename__ = "ecu_t"

    ecu_id = Column(Integer, primary_key=True, index=True)
    ecu_name = Column(String(50), unique=True, nullable=False)
    channels = relationship("Channel", secondary=channel_ecu, back_populates="ecus")





