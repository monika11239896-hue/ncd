from sqlalchemy import Column, Integer, String, Float, Boolean,CheckConstraint, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base
import pytz

from sqlalchemy import Table

IST = pytz.timezone("Asia/Kolkata")

def ist_now():
    return datetime.now(IST)


class Metadata(Base):
    __tablename__ = "metadata_t"

    id = Column(Integer, primary_key=True)
    fileName = Column(String(50), nullable=False)
    version = Column(String(10))
    author = Column(String(20))
    created_at = Column(DateTime, default=ist_now)

    channels = relationship("Channel", back_populates="metadata_p", cascade="all, delete")


ecu_channel = Table(
    "ecu_channel_t",
    Base.metadata,
    Column("ecu_id", ForeignKey("ecu_t.ecu_id", ondelete="CASCADE"), primary_key=True),
    Column("channel_id", ForeignKey("channel_t.channel_id", ondelete="CASCADE"), primary_key=True),
)
class Channel(Base):
    __tablename__ = "channel_t"

    channel_id = Column(Integer, primary_key=True)
    channel_name = Column(String(50), nullable=False)

    metadata_id = Column(Integer, ForeignKey("metadata_t.id"), nullable=False)

    metadata_p = relationship("Metadata", back_populates="channels")
    ecus = relationship("ECU", secondary=ecu_channel, back_populates="channels")


class ECU(Base):
    __tablename__ = "ecu_t"

    ecu_id = Column(Integer, primary_key=True)
    ecu_name = Column(String(50), unique=True, nullable=False)

    channels = relationship("Channel", secondary=ecu_channel, back_populates="ecus")
    messages = relationship("Message", secondary="msg_ecu_channel_t", back_populates="ecus")


class Message(Base):
    __tablename__ = "messages_t"

    message_id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    length = Column(Integer, nullable=False)
    is_extended = Column(Boolean, default=False)
    send_type = Column(String(10))
    cycle_time = Column(Integer)
    comment = Column(Text)

    ecus = relationship("ECU", secondary="msg_ecu_channel_t", back_populates="messages")
    signals = relationship("Signal", back_populates="message", cascade="all, delete")

class MsgEcuChannel(Base):
    __tablename__ = "msg_ecu_channel_t"

    message_id = Column(Integer, ForeignKey("messages_t.message_id"), primary_key=True)
    ecu_id = Column(Integer, ForeignKey("ecu_t.ecu_id"), primary_key=True)
    channel_id = Column(Integer, ForeignKey("channel_t.channel_id"))
    tx_rx_info = Column(Integer, nullable=False)

class Signal(Base):
    __tablename__ = "signals_t"

    signal_id = Column(Integer, primary_key=True, index=True)
    sig_name = Column(String(255), nullable=False)
    start_bit = Column(Integer)
    length = Column(Integer)

    is_signed = Column(Boolean, default=False)
    is_float = Column(Boolean, default=False)
    is_multiplexed = Column(String(10))
    multiplex_val = Column(String(50))

    endianness = Column(String(20), nullable=False)
    factor = Column(Float, default=1.0)
    offset = Column(Float, default=0.0)
    min_value = Column(Float)
    max_value = Column(Float)

    initial_value = Column(String(50))
    unit = Column(String(64))
    comment = Column(Text)
    value_desc = Column(Text)  # JSON stored as TEXT

    message_id = Column(Integer, ForeignKey("messages_t.message_id"), nullable=False)
    message = relationship("Message", back_populates="signals")


class SignalReceiverECU(Base):
    __tablename__ = "signal_receiverecu_t"

    ecu_id = Column(Integer, ForeignKey("ecu_t.ecu_id", ondelete="CASCADE"), primary_key=True)
    signal_id = Column(Integer, ForeignKey("signals_t.signal_id", ondelete="CASCADE"), primary_key=True)
    message_id = Column(Integer, ForeignKey("messages_t.message_id", ondelete="CASCADE"))

class AttributeValue(Base):
    __tablename__ = "attribute_value_t"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(50))

    ecu_id = Column(Integer, ForeignKey("ecu_t.ecu_id", ondelete="CASCADE"), nullable=True)
    message_id = Column(Integer, ForeignKey("messages_t.message_id", ondelete="CASCADE"), nullable=True)
    signal_id = Column(Integer, ForeignKey("signals_t.signal_id", ondelete="CASCADE"), nullable=True)

    int_value = Column(Integer)
    float_value = Column(Float)
    string_value = Column(Text)

    __table_args__ = (
        CheckConstraint(
            "(ecu_id IS NOT NULL) + "
            "(message_id IS NOT NULL) + "
            "(signal_id IS NOT NULL) = 1",
            name="only_one_parent"
        ),
    )

from pydantic import BaseModel
from typing import List

class ECUOut(BaseModel):
    ecu_id: int
    ecu_name: str

    class Config:
        orm_mode = True


class ChannelOut(BaseModel):
    channel_id: int
    channel_name: str
    metadata_id: int
    ecus: List[ECUOut]

    class Config:
        orm_mode = True

