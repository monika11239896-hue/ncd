from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from fastapi import HTTPException
from . import models
from .database import Base, engine, SessionLocal
from .models import Metadata,ECU, Channel
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
from fastapi import HTTPException

# CREATE TABLES (ONLY THIS)
models.Base.metadata.create_all(bind=engine)


app = FastAPI()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "../frontend")

# Serve static files (CSS, JS)
app.mount(
    "/assets",
    StaticFiles(directory=os.path.join(FRONTEND_DIR, "assets")),
    name="assets"
)

# Homepage
@app.get("/")
def homepage():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/topology.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "topology.html"))

@app.get("/topology.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "topology.html"))


@app.get("/add-message.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "add-message.html"))

@app.get("/add-signal.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "add-signal.html"))

# Allow frontend JS to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# DB dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/api/metadata")
def create_metadata(data: dict, db: Session = Depends(get_db)):
    row = Metadata(
        fileName=data["fileName"],
        version=data.get("version"),
        author=data.get("author")
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@app.get("/api/metadata")
def list_metadata(db: Session = Depends(get_db)):
    return db.query(Metadata).order_by(Metadata.created_at.desc()).all()

@app.delete("/api/metadata/{id}", status_code=204)
def delete_metadata(id: int, db: Session = Depends(get_db)):
    row = db.query(Metadata).filter(Metadata.id == id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")

    db.delete(row)
    db.commit()

@app.get("/api/metadata/{id}")
def get_metadata(id: int, db: Session = Depends(get_db)):
    row = db.query(Metadata).filter(Metadata.id == id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")
    return row

@app.post("/api/channels")
def create_channel(data: dict, db: Session = Depends(get_db)):
    name = data.get("channel_name")
    metadata_id = data.get("metadata_id")
    ecu_ids = data.get("ecu_ids", [])

    if not name or not metadata_id:
        raise HTTPException(status_code=400, detail="Invalid data")

    channel = Channel(
        channel_name=name,
        metadata_id=metadata_id
    )

    if ecu_ids:
        ecus = db.query(ECU).filter(ECU.ecu_id.in_(ecu_ids)).all()
        channel.ecus = ecus

    db.add(channel)
    db.commit()
    db.refresh(channel)

    return channel

@app.get("/api/channels")
def list_channels(db: Session = Depends(get_db)):
    return db.query(Channel).all()
from fastapi import HTTPException

@app.post("/api/ecus")
def create_ecu(data: dict, db: Session = Depends(get_db)):
    name = data.get("ecu_name")

    if not name:
        raise HTTPException(status_code=400, detail="ECU name required")

    exists = db.query(ECU).filter(ECU.ecu_name == name).first()
    if exists:
        raise HTTPException(status_code=400, detail="ECU already exists")

    ecu = ECU(ecu_name=name)
    db.add(ecu)
    db.commit()
    db.refresh(ecu)
    return ecu


@app.get("/api/ecus")
def list_ecus(db: Session = Depends(get_db)):
    return db.query(ECU).order_by(ECU.ecu_name).all()
