from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy.orm import joinedload
from fastapi import HTTPException
from . import models
from .database import Base, engine, SessionLocal
from .models import Metadata,ECU, Channel, Message, Signal, MsgEcuChannel, SignalReceiverECU, ChannelOut
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os
from fastapi import HTTPException

# CREATE TABLES (ONLY THIS)
models.Base.metadata.create_all(bind=engine)


app = FastAPI()

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.path.join(BASE_DIR, "../frontend")

# Serve static files (CSS, JS)
app.mount(
    "/assets",
    StaticFiles(directory=os.path.join(FRONTEND_DIR, "assets")),
    name="assets"
)

# Homepage
@app.get("/")
def homepage():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/topology.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "topology.html"))

@app.get("/add-message.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "add-message.html"))

@app.get("/addSig.html")
def topology_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "addSig.html"))

# Allow frontend JS to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# DB dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/api/metadata")
def create_metadata(data: dict, db: Session = Depends(get_db)):
    row = Metadata(
        fileName=data["fileName"],
        version=data.get("version"),
        author=data.get("author")
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@app.get("/api/metadata")
def list_metadata(db: Session = Depends(get_db)):
    return db.query(Metadata).order_by(Metadata.created_at.desc()).all()

@app.delete("/api/metadata/{id}", status_code=204)
def delete_metadata(id: int, db: Session = Depends(get_db)):
    row = db.query(Metadata).filter(Metadata.id == id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")

    db.delete(row)
    db.commit()

@app.get("/api/metadata/{id}")
def get_metadata(id: int, db: Session = Depends(get_db)):
    row = db.query(Metadata).filter(Metadata.id == id).first()
    if not row:
        raise HTTPException(status_code=404, detail="Not found")
    return row

@app.post("/api/channels")
def create_channel(data: dict, db: Session = Depends(get_db)):
    name = data.get("channel_name")
    metadata_id = data.get("metadata_id")
    ecu_ids = data.get("ecu_ids", [])

    if not name or not metadata_id:
        raise HTTPException(status_code=400, detail="Invalid data")

    channel = Channel(
        channel_name=name,
        metadata_id=metadata_id
    )

    if ecu_ids:
        ecus = db.query(ECU).filter(ECU.ecu_id.in_(ecu_ids)).all()
        channel.ecus = ecus

    db.add(channel)
    db.commit()
    db.refresh(channel)

    return channel

@app.get("/api/channels", response_model=list[ChannelOut])
def list_channels(db: Session = Depends(get_db)):
    channels = (
        db.query(Channel)
        .options(joinedload(Channel.ecus))
        .all()
    )
    return channels

@app.post("/api/ecus")
def create_ecu(data: dict, db: Session = Depends(get_db)):
    name = data.get("ecu_name")

    if not name:
        raise HTTPException(status_code=400, detail="ECU name required")

    exists = db.query(ECU).filter(ECU.ecu_name == name).first()
    if exists:
        raise HTTPException(status_code=400, detail="ECU already exists")

    ecu = ECU(ecu_name=name)
    db.add(ecu)
    db.commit()
    db.refresh(ecu)
    return ecu


@app.get("/api/ecus")
def list_ecus(db: Session = Depends(get_db)):
    return db.query(ECU).order_by(ECU.ecu_name).all()


@app.post("/api/messages")
def create_message(data: dict, db: Session = Depends(get_db)):
    if not data.get("name") or not data.get("channel_id"):
        raise HTTPException(400, "Invalid data")

    msg = Message(
        name=data["name"],
        length=data["length"],
        is_extended=data.get("is_extended", False),
        send_type=data.get("send_type"),
        cycle_time=data.get("cycle_time"),
        comment=data.get("comment"),
        channel_id=data["channel_id"]
    )

    db.add(msg)
    db.commit()
    db.refresh(msg)
    return msg

@app.get("/api/channels/{channel_id}/messages")
def list_messages(channel_id: int, db: Session = Depends(get_db)):
    return (
        db.query(Message)
        .join(MsgEcuChannel)
        .filter(MsgEcuChannel.channel_id == channel_id)
        .distinct()
        .all()
    )

@app.post("/api/signals")
def create_signal(data: dict, db: Session = Depends(get_db)):
    required = ["sig_name", "message_id", "endianness"]
    for r in required:
        if r not in data:
            raise HTTPException(400, f"{r} required")

    sig = Signal(
        sig_name=data["sig_name"],
        start_bit=data.get("start_bit"),
        length=data.get("length"),
        is_signed=data.get("is_signed", False),
        is_float=data.get("is_float", False),
        is_multiplexed=data.get("is_multiplexed"),
        multiplex_val=data.get("multiplex_val"),
        endianness=data["endianness"],
        factor=data.get("factor", 1.0),
        offset=data.get("offset", 0.0),
        min_value=data.get("min_value"),
        max_value=data.get("max_value"),
        initial_value=data.get("initial_value"),
        unit=data.get("unit"),
        comment=data.get("comment"),
        value_desc=data.get("value_desc"),
        message_id=data["message_id"]
    )

    db.add(sig)
    db.commit()
    db.refresh(sig)
    return sig


@app.post("/api/signals/{signal_id}/receivers")
def assign_signal_receivers(
    signal_id: int,
    data: dict,
    db: Session = Depends(get_db)
):
    ecu_ids = data.get("ecu_ids", [])
    message_id = data.get("message_id")

    if not ecu_ids or not message_id:
        raise HTTPException(400, "Invalid data")

    for ecu_id in ecu_ids:
        mapping = SignalReceiverECU(
            ecu_id=ecu_id,
            signal_id=signal_id,
            message_id=message_id
        )
        db.add(mapping)

    db.commit()
    return {"status": "receivers assigned"}


@app.get("/api/metadata/{metadata_id}/channels")
def list_channels_for_metadata(metadata_id: int, db: Session = Depends(get_db)):
    return (
        db.query(Channel)
        .filter(Channel.metadata_id == metadata_id)
        .all()
    )

@app.delete("/api/channels/{channel_id}", status_code=204)
def delete_channel(channel_id: int, db: Session = Depends(get_db)):
    channel = db.query(Channel).filter(
        Channel.channel_id == channel_id
    ).first()

    if not channel:
        raise HTTPException(status_code=404, detail="Channel not found")

    db.delete(channel)
    db.commit()

