document.addEventListener('DOMContentLoaded', () => {

  // -------------------
  // Add ECU helper
  // -------------------
  function addEcu(listId, value) {
    if (!value) return;

    const ul = document.getElementById(listId);
    if (!ul) return;

    const li = document.createElement('li');
    li.innerHTML = `
      <span>${value}</span>
      <a href="#" class="delete-item text-danger ms-2">Delete</a>
    `;

    ul.appendChild(li);
  }

  // -------------------
  // Bind Add ECU buttons
  // -------------------
  const xyzAddBtn = document.getElementById('xyzAddBtn');
  const mnoAddBtn = document.getElementById('mnoAddBtn');

  if (xyzAddBtn) {
    xyzAddBtn.addEventListener('click', () => {
      const input = document.getElementById('xyzInput');
      if (!input) return;

      addEcu('xyzList', input.value.trim());
      input.value = '';
      input.focus();
    });
  }

  if (mnoAddBtn) {
    mnoAddBtn.addEventListener('click', () => {
      const input = document.getElementById('mnoInput');
      if (!input) return;

      addEcu('mnoList', input.value.trim());
      input.value = '';
      input.focus();
    });
  }

  // -------------------
  // Delegated delete
  // -------------------
  document.body.addEventListener('click', (e) => {
    const target = e.target;
    if (target.classList.contains('delete-item')) {
      e.preventDefault();
      const li = target.closest('li');
      if (li) li.remove();
    }
  });


  const saveBtn = document.getElementById("saveTopologyBtn");
  if (saveBtn) {
  saveBtn.addEventListener("click", async () => {
    const name = document.getElementById("topologyName").value;
    const version = document.getElementById("topologyVersion").value;
    const author = document.getElementById("topologyAuthor").value;

    if (!name) {
      alert("File name is required");
      return;
    }

    try {
      const response = await fetch("/api/metadata", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          fileName: name,
          version,
          author
        })
      });

      if (!response.ok) {
        const err = await response.text();
        console.error(err);
        alert("Failed to save topology");
        return;
      }
      const result = await response.json();
      window.location.href = `/topology.html?id=${result.id}`;
    } catch (e) {
      console.error(e);
      alert("Network error");
    }
  });
}

   
  // ===== ECU → Messages → Signals data =====
const ecuData = [
  {
    ecu: "ecu_1",
    messages: [
      { name: "msg_1", signals: ["sig_1", "sig_2"] },
      { name: "msg_2", signals: ["sig_3"] }
    ]
  },
  {
    ecu: "ecu_2",
    messages: [
      { name: "msg_a", signals: [] }
    ]
  },
  {
    ecu: "ecu_3",
    messages: []
  }
];

// ===== Render ECU List =====
function renderEcuList() {
  const container = document.getElementById("ecuList");
  if (!container) return;
  container.innerHTML = "";

  ecuData.forEach((ecu, i) => {
    const ecuCollapseId = `ecuCollapse_${i}`;

    const ecuBlock = document.createElement("div");
    ecuBlock.className = "mb-2";

    ecuBlock.innerHTML = `
      <div class="d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-2">
          <span class="chevron bi bi-chevron-right"
                data-bs-toggle="collapse"
                data-bs-target="#${ecuCollapseId}">
          </span>
          <strong>${ecu.ecu}</strong>
        </div>
        <span>
          <a href="#">View</a> /
          <a href="#">Edit</a> /
          <a href="#" class="text-danger">Delete</a>
        </span>
      </div>

      <div class="collapse ms-4 mt-1" id="${ecuCollapseId}">
        ${
          ecu.messages.length
            ? ecu.messages.map(msg => `
                <div class="mt-1">
                  ↪ ${msg.name}
                  ${
                    msg.signals.length
                      ? `<ul class="list-unstyled ms-4 mt-1">
                          ${msg.signals.map(sig =>
                            `<li>↪ ${sig}</li>`
                          ).join("")}
                        </ul>`
                      : `<div class="text-muted ms-4">No signals</div>`
                  }
                </div>
              `).join("")
            : `<div class="text-muted">No messages</div>`
        }
      </div>
    `;

    container.appendChild(ecuBlock);
  });

  bindChevronRotation();
}

// ===== Chevron rotation =====
function bindChevronRotation() {
  document.querySelectorAll(".chevron").forEach(ch => {
    const target = document.querySelector(ch.dataset.bsTarget);

    target.addEventListener("shown.bs.collapse", () =>
      ch.classList.add("rotate")
    );
    target.addEventListener("hidden.bs.collapse", () =>
      ch.classList.remove("rotate")
    );
  });
}

// Initial render
renderEcuList();


const saveEcuBtn = document.getElementById("saveEcuBtn");
if (saveEcuBtn) {
  saveEcuBtn.addEventListener("click", async () => {
    const ecuName = document.getElementById("ecuNameInput").value.trim();

    if (!ecuName) {
      alert("ECU name is required");
      return;
    }

    try {
      const res = await fetch("/api/ecus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ecu_name: ecuName
        })
      });

      const data = await res.json();

      if (!res.ok) {
        alert(data.detail || "Failed to create ECU");
        return;
      }

      alert(`ECU "${data.ecu_name}" created successfully`);

      // Close modal
      bootstrap.Modal.getInstance(
        document.getElementById("addEcuModal")
      ).hide();

      // Reset input
      document.getElementById("ecuNameInput").value = "";

      // OPTIONAL: reload ECU list in CAN modal
      if (typeof loadECUs === "function") {
        loadECUs();
      }

    } catch (err) {
      console.error(err);
      alert("Network error");
    }
  });
}

  /* ===============================
     LOAD METADATA LIST
  =============================== */
  async function loadMetadata() {
    try {
      const response = await fetch("/api/metadata");
      const data = await response.json();

      const container = document.getElementById("fileList");
      if (!container) return;

      container.innerHTML = "";

      if (data.length === 0) {
        container.innerHTML = `<div class="text-muted">No files found</div>`;
        return;
      }

      data.forEach((item, index) => {
        container.innerHTML += `
          <div class="list-group-item d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-3">
              <span class="file-index">${index + 1}.</span>
              <div>
                <div class="file-name fw-bold">${item.fileName}</div>
                <small class="text-muted">
                  Version: ${item.version || "-"} |
                  Author: ${item.author || "-"}
                </small>
              </div>
            </div>

            <div class="row-actions text-end">
              <small class="text-muted me-3">
                ${timeAgo(item.created_at)}
              </small>
              <a href="/topology.html?id=${item.id}">View</a>
              <span class="mx-1">/</span>
              <a href="#">Edit</a>
              <span class="mx-1">/</span>
              <a href="#" class="text-danger"
                 onclick="deleteMetadata(${item.id})">
                 Delete
              </a>
            </div>
          </div>
        `;
      });

    } catch (err) {
      console.error("Failed to load metadata", err);
    }
  }

  /* ===============================
     DELETE METADATA
  =============================== */
  window.deleteMetadata = async function (id) {
    if (!confirm("Delete this file?")) return;

    const res = await fetch(`/api/metadata/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      loadMetadata();
    } else {
      alert("Delete failed");
    }
  };

  /* ===============================
     TIME AGO HELPER
  =============================== */
  function timeAgo(dateString) {
    const diff = Math.floor((Date.now() - new Date(dateString)) / 60000);
    if (diff < 1) return "Just now";
    if (diff < 60) return `${diff} minutes ago`;
    if (diff < 1440) return `${Math.floor(diff / 60)} hours ago`;
    return `${Math.floor(diff / 1440)} days ago`;
  }

  /* ===============================
     INIT
  =============================== */
  loadMetadata();

/* ===============================
   LOAD TOPOLOGY HEADER
================================ */
async function loadTopologyHeader() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");

  if (!id) return;

  try {
    const res = await fetch(`/api/metadata/${id}`);
    if (!res.ok) throw new Error("Not found");

    const data = await res.json();

    document.querySelector("[data-topology-name]").textContent = data.fileName;
    document.querySelector("[data-topology-id]").textContent = data.id;
    document.querySelector("[data-topology-version]").textContent = data.version || "—";
    document.querySelector("[data-topology-author]").textContent = data.author || "—";

    document.getElementById("metaDate").textContent =
      new Date(data.created_at).toLocaleString("en-IN", {
        day: "2-digit",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit"
      });

  } catch (err) {
    console.error(err);
    alert("Failed to load topology info");
  }
}

if (window.location.pathname.includes("topology.html")) {
  loadTopologyHeader();
}


  document.getElementById("canChannelForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const channelName = document.getElementById("canName").value.trim();
  const metadataId = new URLSearchParams(window.location.search).get("id");

  const selectedEcus = Array.from(
    document.querySelectorAll("#ecuCheckboxList input:checked")
  ).map(cb => cb.value);

  if (!channelName || !metadataId) {
    alert("Channel name missing");
    return;
  }

  const res = await fetch("/api/channels", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      channel_name: channelName,
      metadata_id: metadataId,
      ecu_ids: selectedEcus
    })
  });

  if (!res.ok) {
    const err = await res.json();
    alert(err.detail || "Failed to create channel");
    return;
  }

  alert("CAN Channel created");

  bootstrap.Modal.getInstance(
    document.getElementById("canChannelModal")
  ).hide();

  e.target.reset();
});


  async function loadEcusForChannelModal() {
  try {
    const res = await fetch("/api/ecus");
    const ecus = await res.json();

    const container = document.getElementById("ecuCheckboxList");
    if (!container) return;

    container.innerHTML = "";

    if (ecus.length === 0) {
      container.innerHTML = `<div class="text-muted">No ECUs available</div>`;
      return;
    }

    ecus.forEach(ecu => {
      container.innerHTML += `
        <div class="form-check">
          <input class="form-check-input"
                 type="checkbox"
                 value="${ecu.ecu_id}"
                 id="ecu_${ecu.ecu_id}">
          <label class="form-check-label" for="ecu_${ecu.ecu_id}">
            ${ecu.ecu_name}
          </label>
        </div>
      `;
    });

  } catch (err) {
    console.error("Failed to load ECUs", err);
  }
}
const canModal = document.getElementById("canChannelModal");

if (canModal) {
  canModal.addEventListener("show.bs.modal", loadEcusForChannelModal);
}



});

