let messageIndex = 0;

// Mock data
const ecuList = ["ecu_1", "ecu_2", "ecu_3"];
const canChannels = ["CAN_1", "CAN_2"];

document.getElementById("addMessageBtn").addEventListener("click", addMessage);

document.getElementById("messagesForm").addEventListener("submit", e => {
  e.preventDefault();

  const messages = [];

  document.querySelectorAll(".message-block").forEach(msgBlock => {
    const msg = {
      name: msgBlock.querySelector(".msg-name").value.trim(),
      length: parseInt(msgBlock.querySelector(".msg-length").value, 10),
      isExtended: msgBlock.querySelector(".msg-ext").checked,
      comment: msgBlock.querySelector(".msg-comment").value.trim(),
      sender: msgBlock.querySelector(".msg-sender").value,
      canChannel: msgBlock.querySelector(".msg-can").value,
      signals: []
    };

    msgBlock.querySelectorAll(".signal-block").forEach(sigBlock => {
      msg.signals.push({
        sig_name: sigBlock.querySelector(".sig-name").value.trim(),
        start_bit: parseInt(sigBlock.querySelector(".sig-start").value, 10),
        length: parseInt(sigBlock.querySelector(".sig-length").value, 10),
        is_signed: sigBlock.querySelector(".sig-signed").checked,
        is_float: sigBlock.querySelector(".sig-float").checked,
        is_multiplexed: sigBlock.querySelector(".sig-mux").value || null,
        multiplex_val: sigBlock.querySelector(".sig-mux-val").value || null,
        endianness: sigBlock.querySelector(".sig-endian").value,
        factor: parseFloat(sigBlock.querySelector(".sig-factor").value) || 1.0,
    offset: parseFloat(sigBlock.querySelector(".sig-offset").value) || 0.0,
    min_value: parseFloat(sigBlock.querySelector(".sig-min").value),
    max_value: parseFloat(sigBlock.querySelector(".sig-max").value),
    initial_value: sigBlock.querySelector(".sig-init").value,
    unit: sigBlock.querySelector(".sig-unit").value,
    comment: sigBlock.querySelector(".sig-comment").value,
    value_desc: sigBlock.querySelector(".sig-valuedesc").value
      ? JSON.parse(sigBlock.querySelector(".sig-valuedesc").value)
      : null,
    receiver_ecu: sigBlock.querySelector(".sig-receiver").value
      });
    });

    messages.push(msg);
  });

  console.log("Messages to save:", messages);
  alert("Messages saved successfully");

  window.location.href = "topology.html";
});

// ---------- Helpers ----------

function addMessage() {
  const container = document.getElementById("messagesContainer");
  const idx = messageIndex++;

  const msgDiv = document.createElement("div");
  msgDiv.className = "border rounded p-3 mb-3 message-block";

  msgDiv.innerHTML = `
    <div class="d-flex justify-content-between mb-2">
      <strong>Message</strong>
      <button type="button" class="btn btn-sm btn-link text-danger remove-msg">
        Remove
      </button>
    </div>

    <div class="row g-2 mb-2">
      <div class="col-md-4">
        <input class="form-control form-control-sm msg-name" placeholder="Message Name">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm msg-length" placeholder="Length">
      </div>
      <div class="col-md-2 d-flex align-items-center">
        <input type="checkbox" class="form-check-input me-1 msg-ext"> Extended
      </div>
      <div class="col-md-4">
        <select class="form-select form-select-sm msg-sender">
          <option value="">Sender ECU</option>
          ${ecuList.map(e => `<option>${e}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="mb-2">
      <select class="form-select form-select-sm msg-can">
        <option value="">CAN Channel</option>
        ${canChannels.map(c => `<option>${c}</option>`).join("")}
      </select>
    </div>

    <textarea class="form-control form-control-sm mb-2 msg-comment"
              placeholder="Comment"></textarea>

    <div class="signals-container"></div>

    <button type="button"
            class="btn btn-outline-secondary btn-sm add-signal">
      + Add Signal
    </button>
  `;

  msgDiv.querySelector(".remove-msg").onclick = () => msgDiv.remove();
  msgDiv.querySelector(".add-signal").onclick = () =>
    addSignal(msgDiv.querySelector(".signals-container"));

  container.appendChild(msgDiv);
}

function addSignal(container) {
  const sigDiv = document.createElement("div");
  sigDiv.className = "border rounded p-3 mt-3 signal-block";

  sigDiv.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2">
      <strong>Signal</strong>
      <button type="button" class="btn btn-sm btn-link text-danger remove-sig">
        Remove
      </button>
    </div>

    <div class="row g-2">
      <div class="col-md-4">
        <input class="form-control form-control-sm sig-name" placeholder="Signal Name">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-start" placeholder="Start Bit">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-length" placeholder="Length">
      </div>
      <div class="col-md-2 form-check mt-2">
        <input class="form-check-input sig-signed" type="checkbox">
        <label class="form-check-label small">Signed</label>
      </div>
      <div class="col-md-2 form-check mt-2">
        <input class="form-check-input sig-float" type="checkbox">
        <label class="form-check-label small">Float</label>
      </div>
    </div>

    <div class="row g-2 mt-2">
      <div class="col-md-3">
        <select class="form-select form-select-sm sig-mux">
          <option value="">Not Multiplexed</option>
          <option value="multiplexor">Multiplexor</option>
          <option value="multiplexed">Multiplexed</option>
        </select>
      </div>
      <div class="col-md-3">
        <input class="form-control form-control-sm sig-mux-val"
               placeholder="Multiplex Value"
               disabled>
      </div>
      <div class="col-md-3">
        <select class="form-select form-select-sm sig-endian">
          <option value="little_endian">Little Endian</option>
          <option value="big_endian">Big Endian</option>
        </select>
      </div>
      <div class="col-md-3">
        <select class="form-select form-select-sm sig-receiver">
          <option value="">Receiver ECU</option>
          ${ecuList.map(e => `<option>${e}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="row g-2 mt-2">
      <div class="col-md-2">
        <input type="number" step="0.01" class="form-control form-control-sm sig-factor" placeholder="Factor" value="1">
      </div>
      <div class="col-md-2">
        <input type="number" step="0.01" class="form-control form-control-sm sig-offset" placeholder="Offset" value="0">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-min" placeholder="Min">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-max" placeholder="Max">
      </div>
      <div class="col-md-2">
        <input class="form-control form-control-sm sig-init" placeholder="Initial">
      </div>
      <div class="col-md-2">
        <input class="form-control form-control-sm sig-unit" placeholder="Unit">
      </div>
    </div>

    <textarea class="form-control form-control-sm mt-2 sig-comment"
              placeholder="Comment"></textarea>

    <textarea class="form-control form-control-sm mt-2 sig-valuedesc"
              placeholder='Value Description JSON (e.g. {"0":"OFF","1":"ON"})'></textarea>
  `;

  // Multiplex toggle logic
  const muxSelect = sigDiv.querySelector(".sig-mux");
  const muxVal = sigDiv.querySelector(".sig-mux-val");

  muxSelect.addEventListener("change", () => {
    muxVal.disabled = muxSelect.value !== "multiplexed";
    if (muxVal.disabled) muxVal.value = "";
  });

  sigDiv.querySelector(".remove-sig").onclick = () => sigDiv.remove();
  container.appendChild(sigDiv);
}

