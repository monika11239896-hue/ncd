// Mock data (replace later with API / shared store)
const ecuList = ["ecu_1", "ecu_2", "ecu_3"];

document.getElementById("addSignalBtn").addEventListener("click", addSignal);

document.getElementById("signalsForm").addEventListener("submit", e => {
  e.preventDefault();

  const signals = [];

  document.querySelectorAll(".signal-block").forEach(sig => {
    signals.push({
      sig_name: sig.querySelector(".sig-name").value.trim(),
      start_bit: parseInt(sig.querySelector(".sig-start").value, 10),
      length: parseInt(sig.querySelector(".sig-length").value, 10),
      is_signed: sig.querySelector(".sig-signed").checked,
      is_float: sig.querySelector(".sig-float").checked,
      is_multiplexed: sig.querySelector(".sig-mux").value || null,
      multiplex_val: sig.querySelector(".sig-mux-val").value || null,
      endianness: sig.querySelector(".sig-endian").value,
      factor: parseFloat(sig.querySelector(".sig-factor").value) || 1.0,
      offset: parseFloat(sig.querySelector(".sig-offset").value) || 0.0,
      min_value: parseFloat(sig.querySelector(".sig-min").value),
      max_value: parseFloat(sig.querySelector(".sig-max").value),
      initial_value: sig.querySelector(".sig-init").value,
      unit: sig.querySelector(".sig-unit").value,
      comment: sig.querySelector(".sig-comment").value,
      value_desc: sig.querySelector(".sig-valuedesc").value
        ? JSON.parse(sig.querySelector(".sig-valuedesc").value)
        : null,
      receiver_ecu: sig.querySelector(".sig-receiver").value
    });
  });

  console.log("Signals:", signals);
  alert("Signals saved successfully");

  window.location.href = "topology.html";
});

// ---------- Add Signal UI ----------

function addSignal() {
  const container = document.getElementById("signalsContainer");

  const sigDiv = document.createElement("div");
  sigDiv.className = "border rounded p-3 mb-3 signal-block";

  sigDiv.innerHTML = `
    <div class="d-flex justify-content-between align-items-center mb-2">
      <strong>Signal</strong>
      <button type="button" class="btn btn-sm btn-link text-danger remove-sig">
        Remove
      </button>
    </div>

    <div class="row g-2">
      <div class="col-md-4">
        <input class="form-control form-control-sm sig-name" placeholder="Signal Name">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-start" placeholder="Start Bit">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-length" placeholder="Length">
      </div>
      <div class="col-md-2 form-check mt-2">
        <input class="form-check-input sig-signed" type="checkbox">
        <label class="form-check-label small">Signed</label>
      </div>
      <div class="col-md-2 form-check mt-2">
        <input class="form-check-input sig-float" type="checkbox">
        <label class="form-check-label small">Float</label>
      </div>
    </div>

    <div class="row g-2 mt-2">
      <div class="col-md-3">
        <select class="form-select form-select-sm sig-mux">
          <option value="">Not Multiplexed</option>
          <option value="multiplexor">Multiplexor</option>
          <option value="multiplexed">Multiplexed</option>
        </select>
      </div>
      <div class="col-md-3">
        <input class="form-control form-control-sm sig-mux-val"
               placeholder="Multiplex Value"
               disabled>
      </div>
      <div class="col-md-3">
        <select class="form-select form-select-sm sig-endian">
          <option value="little_endian">Little Endian</option>
          <option value="big_endian">Big Endian</option>
        </select>
      </div>
      <div class="col-md-3">
        <!-- ⭐ Receiver ECU dropdown -->
        <select class="form-select form-select-sm sig-receiver">
          <option value="">Receiver ECU</option>
          ${ecuList.map(e => `<option>${e}</option>`).join("")}
        </select>
      </div>
    </div>

    <div class="row g-2 mt-2">
      <div class="col-md-2">
        <input type="number" step="0.01"
               class="form-control form-control-sm sig-factor"
               placeholder="Factor" value="1">
      </div>
      <div class="col-md-2">
        <input type="number" step="0.01"
               class="form-control form-control-sm sig-offset"
               placeholder="Offset" value="0">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-min" placeholder="Min">
      </div>
      <div class="col-md-2">
        <input type="number" class="form-control form-control-sm sig-max" placeholder="Max">
      </div>
      <div class="col-md-2">
        <input class="form-control form-control-sm sig-init" placeholder="Initial">
      </div>
      <div class="col-md-2">
        <input class="form-control form-control-sm sig-unit" placeholder="Unit">
      </div>
    </div>

    <textarea class="form-control form-control-sm mt-2 sig-comment"
              placeholder="Comment"></textarea>

    <textarea class="form-control form-control-sm mt-2 sig-valuedesc"
              placeholder='Value Description JSON (e.g. {"0":"OFF","1":"ON"})'></textarea>
  `;

  // Multiplex toggle
  const muxSelect = sigDiv.querySelector(".sig-mux");
  const muxVal = sigDiv.querySelector(".sig-mux-val");

  muxSelect.addEventListener("change", () => {
    muxVal.disabled = muxSelect.value !== "multiplexed";
    if (muxVal.disabled) muxVal.value = "";
  });

  sigDiv.querySelector(".remove-sig").onclick = () => sigDiv.remove();
  container.appendChild(sigDiv);
}
