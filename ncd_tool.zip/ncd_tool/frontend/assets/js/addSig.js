function addSignal() {

  const container = document.getElementById("signalsContainer");
  const sig = document.createElement("div");
  sig.className = "signal";
  

  sig.innerHTML = `
    <h4>Signal</h4>
    <div class="container">
    
  </div>
	<table>
		<thead>
			<td><label>Signal Name*</label></td>
			<td><label>Start Bit* (0–64)</label></td>
			<td><label>Length* (0–64)</label></td>
			<td><label>is_signed*</label></td>
			<td><label>is_float*</label></td>
			<td><label>is_multiplexed*</label></td>
		</thead>
		<tr>
			<td><input class="sigName"></td>
			<td><input type="number" class="startBit">
				<div class="inline-error startBitError">Start bit cannot be more than 64.</div></td>
			<td><input type="number" class="sigLen">
				<div class="inline-error sigLenError">Signal Length cannot be more than 64.</div></td>
			<td><select class="isSigned"><option>False</option><option>True</option></select></td>
			<td><select class="isFloat"><option>False</option><option>True</option></select></td>
			<td><select class="isMultiplexed"><option>No</option><option>Yes</option></select></td>
		</tr>
	</table>  

		
	<table>
		<thead>
			<td><label>multiplex_val</label></td>
			<td><label>Endianness (FIXED)</label></td>
			<td> <label>Factor*</label></td>
			<td><label>Offset*</label></td>
			<td><label>minimum*</label></td>
			<td> <label>maximum*</label></td>
		</thead>
		<tr>
			<td><input class="multiplexVal" type="number" >
				<div class="inline-error multiplexValError">Multiplex Value cannot be more than 64.</div></td>
			<td><input class="endianness" value="big_endian" disabled></td>
			<td><input type="number" class="factor" value="1">
				<div class="inline-error factorError">Factor Value cannot be more than 64.</div></td>
			<td><input type="number" class="offset" value="0">
				<div class="inline-error offsetError">Offset Value cannot be more than 64.</div></td>
			<td><input type="number" class="minimum" value="0">
				<div class="inline-error minimumError">Minimum Value cannot be more than 64.</div></td>
			<td><input type="number" class="maximum" value="0">
				<div class="inline-error maximumError">Maximum Value cannot be more than 64.</div></td>
		</tr>
	</table>
	
	<table>
		<thead>
			<td><label>Receivers ecu*</label></td>
			<td><label>Comment</label></td>
			<td><label>Initial Value</label></td>
			<td><label>Unit</label></td>
			<td><label>GenSigCycleTime*</label></td>
		</thead>
    
		<tr>
			<td>
      <select class="receivers" style="width:300px">
        <option value="">-- Select ECU --</option>
      </select>
			</td
			<td><input class="sigComment" value=""></td>
			<td><input class="initialValue" value="None"></td>
			<td><input class="unit" value="None"></td>
			<td><input type="number" class="GenSigCycleTime"></td>
		</tr>
	</table>

    <h4>Value Description*</h4>
    <div class="kvPairs"></div>
    <button type="button" class="addKV">+ Add Value</button>

    <br><br>
    <button type="button" onclick="this.parentElement.remove()">Remove Signal</button>
  `;
  // 2️⃣ NOW populate ECU dropdown
  const ecuSelect = sig.querySelector(".receivers");

  ECUS.forEach(e => {
    const opt = document.createElement("option");
    opt.value = e.ecu_id;
    opt.textContent = e.ecu_name;
    ecuSelect.appendChild(opt);
  });

  // Add Key-Value pairs
  sig.querySelector(".addKV").onclick = () => {
    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.gap = "6px";
    row.style.marginBottom = "5px";

    row.innerHTML = `
      <input class="kvKey" placeholder="Key" style="width:60px">
      <input class="kvValue" placeholder="Value" style="flex:1">
      <button type="button" onclick="this.parentElement.remove()">X</button>
    `;
    sig.querySelector(".kvPairs").appendChild(row);
  };

  // REAL-TIME VALIDATION (0–64)
  sig.querySelectorAll("input[type=number]").forEach(input => {
    input.addEventListener("input", () => {
      const v = input.value;
      if (v !== "" && (v < 0 || v > 64)) {
        input.style.borderColor = "red";
      } else {
        input.style.borderColor = "";
      }
    });
  });

  container.appendChild(sig);
  sig.scrollIntoView({ behavior: "smooth" });
}

function validateSignals() {

  const errors = [];
  const signals = [];

  document.querySelectorAll(".signal").forEach((s, i) => {

    const name = s.querySelector(".sigName").value.trim().toUpperCase();
    const sb = s.querySelector(".startBit").value;
    const len = s.querySelector(".sigLen").value;
    const factor = s.querySelector(".factor").value;
    const offset = s.querySelector(".offset").value;
    const min = s.querySelector(".minimum").value;
    const max = s.querySelector(".maximum").value;
    
    const rec = Array.from(
      s.querySelector(".receivers").selectedOptions
    ).map(o => o.value);
    const cyc = s.querySelector(".GenSigCycleTime").value;
    const messageId = document.getElementById("messageSelect").value;
    if (!messageId) {
      errors.push("Message must be selected");
    }

    // ValueDesc
    const kv = {};
    s.querySelectorAll(".kvPairs > div").forEach(d => {
      const k = d.querySelector(".kvKey").value.trim();
      const v = d.querySelector(".kvValue").value.trim();
      if (k) kv[k] = v;
    });

    // HARD CONSTRAINTS (same as your file)
    if (!name) errors.push(`Signal #${i+1}: Name missing`);
    if (!(sb >= 0 && sb <= 64)) errors.push(`${name}: StartBit must be 0–64`);
    if (!(len >= 0 && len <= 64)) errors.push(`${name}: Length must be 0–64`);
    if (!(factor >= 0 && factor <= 64)) errors.push(`${name}: Factor invalid`);
    if (!(offset >= 0 && offset <= 64)) errors.push(`${name}: Offset invalid`);
    if (!(min >= 0 && min <= 64)) errors.push(`${name}: Minimum invalid`);
    if (!(max >= 0 && max <= 64)) errors.push(`${name}: Maximum invalid`);
    if (rec.length !== 1)
      errors.push(`${name}: Exactly least one receiver ECU required`);
    if (cyc === "" || isNaN(cyc)) errors.push(`${name}: GenSigCycleTime required`);
    if (Object.keys(kv).length === 0)
      errors.push(`${name}: ValueDesc required`);

    signals.push({
      SigName: name,
      StartBit: sb,
      Length: len,
      Factor: factor,
      Offset: offset,
      Minimum: min,
      message_id: messageId,
      Maximum: max,
      Receivers: rec,
      GenSigCycleTime: cyc,
      ValueDesc: kv
    });
  });

  if (errors.length > 0) {
    showPopup(errors);
    return;
  }

  alert("All signals valid ✅");
  console.log(signals);
}

function showPopup(errors) {
  document.getElementById("popupErrors").textContent = errors.join("\n");
  document.getElementById("popupModal").style.display = "flex";
}

function closePopup() {
  document.getElementById("popupModal").style.display = "none";
}


window.onload = async () => {
  await loadECUs();
  await loadMessages();
};

async function loadMessages() {
  const res = await fetch("/api/messages");
  const data = await res.json();

  const msgSelect = document.getElementById("messageSelect");
  msgSelect.innerHTML = `<option value="">Select Message</option>`;

  data.forEach(m => {
    msgSelect.innerHTML += `<option value="${m.message_id}">${m.name}</option>`;
  });
}






let ECUS = [];

async function loadECUs() {
  const res = await fetch("/api/ecus");
  ECUS = await res.json();
}