import { API_BASE_URL } from "./config.js";

async function fetchMessages() {
  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/messages`);

    if (!res.ok) {
      throw new Error("Failed to fetch messages");
    }

    const data = await res.json();

    // Adjust if your API wraps data
    messages = Array.isArray(data) ? data : data.items || [];
  } catch (err) {
    console.error("Message fetch error:", err);
    messages = [];
  }
}

// ================= STATE =================
let selectedECU = "";
let selectedChannel = "";

// ================= DOM (lazy init) =================
let tbody;
let globalSearch;

// ================= CORE FUNCTIONS =================
function renderTable() {
  const search = globalSearch.value.toLowerCase();

  const filtered = messages.filter(
    (m) =>
      (!selectedECU || m.ecu === selectedECU) &&
      (!selectedChannel || m.channel === selectedChannel) &&
      (!search ||
        `${m.id} ${m.name} ${m.ecu} ${m.channel}`
          .toLowerCase()
          .includes(search)),
  );

  tbody.innerHTML = "";

  filtered.forEach((m) => {
    tbody.insertAdjacentHTML(
      "beforeend",
      `
      <tr>
        <td>${m.id}</td>
        <td>
         <a href="#" 
          class="message-link"
          data-msg-id="${m.id}"
          data-msg-name="${encodeURIComponent(m.name)}">
          ${m.name}
        </a>
        </td>
        <td><span class="badge badge-ecu">${m.ecu}</span></td>
        <td><span class="badge badge-channel">${m.channel}</span></td>
        <td class="text-end">
          <button class="action-btn"><i class="bi bi-eye"></i></button>
          <button class="action-btn"><i class="bi bi-pencil"></i></button>
          <button class="action-btn text-danger"><i class="bi bi-trash"></i></button>
        </td>
      </tr>
    `,
    );
  });

  tbody.querySelectorAll(".message-link").forEach((link) => {
    link.addEventListener("click", async (e) => {
      e.preventDefault();

      const msgId = link.dataset.msgId;
      const msgName = decodeURIComponent(link.dataset.msgName);

      await openSignalListModal(msgId, msgName);
    });
  });
}

function populateFilters() {
  const ecuSet = [...new Set(messages.map((m) => m.ecu))];
  const channelSet = [...new Set(messages.map((m) => m.channel))];

  const ecuList = document.getElementById("ecuFilterList");
  const channelList = document.getElementById("channelFilterList");

  ecuList.innerHTML =
    `<div class="filter-item" data-ecu="">All</div>` +
    ecuSet
      .map((e) => `<div class="filter-item" data-ecu="${e}">${e}</div>`)
      .join("");

  channelList.innerHTML =
    `<div class="filter-item" data-channel="">All</div>` +
    channelSet
      .map((c) => `<div class="filter-item" data-channel="${c}">${c}</div>`)
      .join("");

  ecuList.querySelectorAll("[data-ecu]").forEach((el) =>
    el.addEventListener("click", () => {
      selectedECU = el.dataset.ecu;
      renderTable();
      closeDropdowns();
    }),
  );

  channelList.querySelectorAll("[data-channel]").forEach((el) =>
    el.addEventListener("click", () => {
      selectedChannel = el.dataset.channel;
      renderTable();
      closeDropdowns();
    }),
  );
}

function closeDropdowns() {
  document.querySelectorAll(".dropdown-menu").forEach((d) => {
    d.classList.remove("show");
  });
}

export function filterDropdown(input, type) {
  const value = input.value.toLowerCase();
  const listId = type === "ecu" ? "ecuFilterList" : "channelFilterList";

  document.querySelectorAll(`#${listId} .filter-item`).forEach((item) => {
    item.style.display =
      item.textContent === "All" ||
      item.textContent.toLowerCase().includes(value)
        ? "block"
        : "none";
  });
}

async function openSignalListModal(messageId, messageName) {
  // Load signal list HTML
  const res = await fetch("pages/signal-list.html");
  const html = await res.text();

  document.getElementById("signalModalBody").innerHTML = html;
  document.getElementById("signalModalTitle").textContent =
    `Signals – ${messageName}`;

  // Show modal
  const modal = new bootstrap.Modal(document.getElementById("signalListModal"));
  modal.show();

  // Init signal list JS
  const sigModule = await import("../js/Sig-list.js");
  sigModule.initSignalListPage(messageId, messageName);
}

export async function initMessageListPage() {
  // DOM available NOW because router injected HTML
  tbody = document.getElementById("messageTableBody");
  globalSearch = document.getElementById("globalSearch");

  if (!tbody || !globalSearch) {
    console.error("Message List DOM not found");
    return;
  }

  globalSearch.addEventListener("input", renderTable);
  await fetchMessages();
  populateFilters();
  renderTable();
}
